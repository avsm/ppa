
#include <sqlite3.h>
#include "connection.h"

int enable_extension(Connection*, int);
